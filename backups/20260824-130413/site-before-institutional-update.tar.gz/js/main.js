/* Hágil Terapêutica — redesign conceitual
   Comportamentos comuns: header, menu, reveals e mapa de distribuição. */

(function () {
  "use strict";

  /* ---------- Header: estado ao rolar ---------- */
  const header = document.querySelector(".site-header");
  const aoRolar = () => header.classList.toggle("rolou", window.scrollY > 24);
  aoRolar();
  window.addEventListener("scroll", aoRolar, { passive: true });

  /* ---------- Menu mobile ---------- */
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const aberto = nav.classList.toggle("aberto");
      toggle.setAttribute("aria-expanded", String(aberto));
    });
    nav.addEventListener("click", (e) => {
      if (e.target.closest("a")) {
        nav.classList.remove("aberto");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ---------- Reveals no scroll ---------- */
  const revelaveis = document.querySelectorAll("[data-reveal]");
  if ("IntersectionObserver" in window && revelaveis.length) {
    const io = new IntersectionObserver(
      (entradas) => {
        entradas.forEach((entrada) => {
          if (entrada.isIntersecting) {
            entrada.target.classList.add("visivel");
            io.unobserve(entrada.target);
          }
        });
      },
      { threshold: 0.16, rootMargin: "0px 0px -6% 0px" }
    );
    revelaveis.forEach((el) => io.observe(el));
  } else {
    revelaveis.forEach((el) => el.classList.add("visivel"));
  }

  /* ---------- Mapa do Brasil em matriz de pontos ---------- */
  const svgMapa = document.getElementById("mapa-brasil");
  if (svgMapa) {
    // Silhueta aproximada do Brasil (1 = ponto)
    const grade = [
      ".......1111..11.............",
      ".....111111111111...........",
      "...11111111111111111........",
      "..111111111111111111111.....",
      ".11111111111111111111111....",
      "111111111111111111111111111.",
      "1111111111111111111111111111",
      ".111111111111111111111111111",
      "..11111111111111111111111111",
      "..1111111111111111111111111.",
      "...111111111111111111111111.",
      "....1111111111111111111111..",
      ".....111111111111111111111..",
      "......11111111111111111111..",
      ".......111111111111111111...",
      ".......11111111111111111....",
      "........111111111111111.....",
      "........11111111111111......",
      ".........111111111111.......",
      ".........1111111111.........",
      "..........11111111..........",
      "..........111111............",
      "...........1111.............",
      "...........111..............",
      "............1..............."
    ];

    // Polos de distribuição (linha, coluna na grade) — capitais + sede
    const polos = [
      [5, 8],   // Manaus (N)
      [4, 16],  // Belém (N)
      [8, 6],   // Porto Velho (N)
      [6, 23],  // Fortaleza (NE)
      [8, 26],  // Recife (NE)
      [11, 22], // Salvador (NE)
      [12, 15], // Brasília (CO)
      [11, 10], // Cuiabá (CO)
      [14, 19], // Belo Horizonte (SE)
      [14, 22], // Teófilo Otoni — sede (SE)
      [16, 16], // São Paulo (SE)
      [18, 14], // Curitiba (S)
      [20, 12]  // Porto Alegre (S)
    ];

    const passo = 16;
    const raio = 3.1;
    const ns = "http://www.w3.org/2000/svg";
    const ehPolo = (l, c) =>
      polos.some(([pl, pc]) => pl === l && pc === c);

    let indicePolo = 0;
    grade.forEach((linha, l) => {
      [...linha].forEach((celula, c) => {
        if (celula !== "1") return;
        const cx = c * passo + passo / 2;
        const cy = l * passo + passo / 2;

        if (ehPolo(l, c)) {
          const eco = document.createElementNS(ns, "circle");
          eco.setAttribute("cx", cx);
          eco.setAttribute("cy", cy);
          eco.setAttribute("r", raio + 2.4);
          eco.setAttribute("class", "polo-eco");
          eco.style.animationDelay = (indicePolo * 0.35) + "s";
          svgMapa.appendChild(eco);

          const ponto = document.createElementNS(ns, "circle");
          ponto.setAttribute("cx", cx);
          ponto.setAttribute("cy", cy);
          ponto.setAttribute("r", raio + 1.4);
          ponto.setAttribute("class", "polo");
          svgMapa.appendChild(ponto);
          indicePolo += 1;
        } else {
          const ponto = document.createElementNS(ns, "circle");
          ponto.setAttribute("cx", cx);
          ponto.setAttribute("cy", cy);
          ponto.setAttribute("r", raio);
          ponto.setAttribute("class", "ponto");
          svgMapa.appendChild(ponto);
        }
      });
    });
  }
})();
